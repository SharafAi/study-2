// run: npm install archiver
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

const projectRoot = __dirname; // your project path
const outputZip = path.join(projectRoot, 'project_backup.zip');

const output = fs.createWriteStream(outputZip);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => {
  console.log(`Backup created: ${outputZip} (${archive.pointer()} total bytes)`);
});

archive.on('error', err => { throw err; });

archive.pipe(output);

// add the entire project folder except the zip itself
archive.glob('**/*', {
  cwd: projectRoot,
  ignore: ['project_backup.zip', 'node_modules/**'] // optional ignores
});

archive.finalize();